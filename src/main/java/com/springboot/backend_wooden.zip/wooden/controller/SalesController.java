package com.springboot.wooden.controller;

import com.springboot.wooden.service.SalesService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/sales")
@RequiredArgsConstructor
public class SalesController {

    private final SalesService salesService;

    /** 월별 매출: [{ ym, total }] */
    @GetMapping("/monthly")
    public List<Map<String, Object>> monthlySales() {
        return salesService.getMonthlySales();
    }

    /** 특정 월 Top10: ym은 "2025-1"처럼 와도 서비스에서 "2025-01"로 보정 */
    @GetMapping("/item-qty-monthly")
    public List<Map<String, Object>> itemQtyMonthly(@RequestParam String ym) {
        return salesService.getItemQtyTop10ByMonth(ym);
    }

    /** 모든 월×상품 수량 (디버깅/드롭다운 용도) */
    @GetMapping("/item-qty-monthly-all")
    public List<Map<String, Object>> itemQtyMonthlyAll() {
        return salesService.getItemQtyMonthlyAll();
    }
}
