package com.springboot.wooden.repository;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@RequiredArgsConstructor
public class SalesRepository {

    private final JdbcTemplate jdbcTemplate;

    /** 월별 매출: 라인 금액(order_price) 합계, ym = YYYY-MM 고정
     *  - order_amount가 있으면 그걸 쓰고, 없으면 order_qty * item_price로 계산:
     */
    public List<Map<String, Object>> findMonthlySales() {
        String sql = """
        SELECT DATE_FORMAT(o.order_date, '%Y-%m') AS ym,
               SUM(COALESCE(o.order_amount, o.order_qty * i.item_price)) AS total
        FROM order_tbl o
        JOIN item_tbl  i ON i.item_no = o.item_no
        GROUP BY ym
        ORDER BY ym
        """;
        return jdbcTemplate.queryForList(sql);
    }

    /** 특정 월 Top10: 수량 합계, ym = YYYY-MM 고정 */
    public List<Map<String, Object>> findItemQtyTop10ByMonth(String ymYYYYMM) {
        String sql = """
            SELECT i.item_no   AS itemNo,
                   i.item_name AS itemName,
                   SUM(COALESCE(o.order_qty, 0)) AS qty
            FROM order_tbl o
            JOIN item_tbl i ON o.item_no = i.item_no
            WHERE DATE_FORMAT(o.order_date, '%Y-%m') = ?
            GROUP BY i.item_no, i.item_name
            ORDER BY qty DESC
            LIMIT 10
        """;
        return jdbcTemplate.queryForList(sql, ymYYYYMM);
    }

    /** 모든 월×상품 수량 (드롭다운/차트 디버깅용): ym 포함해서 반환 */
    public List<Map<String, Object>> findItemQtyMonthlyAll() {
        String sql = """
            SELECT DATE_FORMAT(o.order_date, '%Y-%m') AS ym,
                   i.item_no   AS itemNo,
                   i.item_name AS itemName,
                   SUM(COALESCE(o.order_qty, 0)) AS totalQty
            FROM order_tbl o
            JOIN item_tbl i ON o.item_no = i.item_no
            GROUP BY ym, i.item_no, i.item_name
            ORDER BY ym, totalQty DESC
        """;
        return jdbcTemplate.queryForList(sql);
    }
}
