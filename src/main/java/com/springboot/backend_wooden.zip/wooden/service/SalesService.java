package com.springboot.wooden.service;

import com.springboot.wooden.repository.SalesRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class SalesService {

    private final SalesRepository salesRepository;

    /** 월별 매출: { ym: "YYYY-MM", total: number }[] */
    public List<Map<String, Object>> getMonthlySales() {
        var rows = salesRepository.findMonthlySales();
        return rows.stream().map(r -> {
            Map<String, Object> m = new HashMap<>();
            m.put("ym",    r.get("ym"));
            m.put("total", r.get("total"));
            return m;
        }).toList();
    }

    /** 특정 월 Top10: ym은 어떤 포맷이 와도 YYYY-MM으로 보정 후 조회 */
    public List<Map<String, Object>> getItemQtyTop10ByMonth(String ymAnyFormat) {
        String ym = normalizeYYYYMM(ymAnyFormat); // "2025-1" → "2025-01"
        var rows = salesRepository.findItemQtyTop10ByMonth(ym);
        return rows.stream().map(r -> {
            Map<String, Object> m = new HashMap<>();
            m.put("itemNo",   r.get("itemNo"));
            m.put("itemName", r.get("itemName"));
            m.put("qty",      r.get("qty"));
            return m;
        }).toList();
    }

    /** 모든 월×상품 수량: { ym,itemNo,itemName,totalQty }[] */
    public List<Map<String, Object>> getItemQtyMonthlyAll() {
        var rows = salesRepository.findItemQtyMonthlyAll();
        return rows.stream().map(r -> {
            Map<String, Object> m = new HashMap<>();
            m.put("ym",       r.get("ym"));          // ← 기존 month 키 오타/불일치 수정
            m.put("itemNo",   r.get("itemNo"));
            m.put("itemName", r.get("itemName"));
            m.put("totalQty", r.get("totalQty"));
            return m;
        }).toList();
    }

    /** "YYYY-M", "YYYY/MM", "YYYYMM", "YYYY-MM-dd" 등을 "YYYY-MM"으로 정규화 */
    private String normalizeYYYYMM(String input) {
        if (input == null) return null;
        String s = input.trim();
        if (s.isEmpty()) return null;

        // 구분자 통일
        s = s.replace('.', '-')
                .replace('/', '-')
                .replace('_', '-')
                .replace(' ', '-')
                .replaceAll("-+", "-");

        // 202510 -> 2025-10
        if (s.matches("^\\d{6}$")) {
            String y = s.substring(0, 4);
            int m = Integer.parseInt(s.substring(4, 6));
            return y + "-" + String.format("%02d", m);
        }

        // 2025-10-15 -> 2025-10  /  2025-1 -> 2025-01
        if (s.matches("^\\d{4}-\\d{1,2}(-.*)?$")) {
            String[] parts = s.split("-");
            String y = parts[0];
            int m = Integer.parseInt(parts[1]);
            return y + "-" + String.format("%02d", m);
        }

        // 이미 YYYY-MM 라면 그대로
        if (s.matches("^\\d{4}-\\d{2}$")) return s;

        return s; // 혹시 모를 포맷은 그대로 반환
    }
}
